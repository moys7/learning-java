package test.mypac;

public class Cpu {

}
