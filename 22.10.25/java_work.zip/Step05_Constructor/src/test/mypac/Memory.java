package test.mypac;

public class Memory {

}
