//이 클래스가 속해있는 패키지명을 밝혀 주어야 한다.
package test.main;
/*
 * 
 *하나
 *둘
 *
 */
//public ->공개된(모든 패키지에서 사용할 수 있는) 
//class->클래스, 
//MainClass2->클래스명은 MainClass2
public class MainClass2 {//클래스의 시작
	/*
	 * 메소드명 :main
	 * run 했을떄 실행이 시작되는 아주 특별한 메소드
	 */
	public static void main(String[] args) {
	
	}
	
}//클래스의 끝
