package test.mypac;

public class MyUtil {
	//필드
	public static String version;
	
	//메소드
	public static void send() {
		System.out.println("전송합니다.");
	}
}
