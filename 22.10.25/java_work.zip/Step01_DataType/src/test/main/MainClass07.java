package test.main;

public class MainClass07 {
	//run 했을때 실행의 흐름이 시작되는 아주 특별한 메소드
	public static void main(String[] args) {
		// 지역 변수를 미리 만들고 나중에 필요한 값을 넣고 싶으면 초기값을 대입하는 것이 좋다.
		int num1=0;
		String name1=null;
		
		//필요시에 값 넣기
		num1=10;
		name1="김구라";
	}
}
