package test.main;
/*
 * 5.대입연산자 테스트
 * 
 * +=, -=, *=, /=, %=
 */
public class MainClass05 {
	public static void main(String[] args) {
		
		int num=10;
		//num= num+2;
		num+= 2;
		//num= num-3;
		num-= 3;
		//num= num*4;
		num*= 4;
		//num= num/5;
		num/= 5;
		//num= num%6;
		num%= 6;
	}
}
